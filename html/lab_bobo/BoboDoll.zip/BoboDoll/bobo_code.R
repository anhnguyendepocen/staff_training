# my required libraries
library("dplyr")
library("ggplot2")

# load in my data
scores <- read.csv("bobo.csv", stringsAsFactors = FALSE, 
                   colClasses = c("character", "character", 
                       "integer", "character", "integer"))

# produce a histogram of the data
ggplot(scores, aes(Violence)) +
  geom_bar(fill="blue", col = "black") +
  facet_wrap(~Sex + Conds) +
  geom_density(aes(y=..count..), colour="black", size = 1) +
  labs(title = "Histograms") +
  labs(x = "Groups") +
  theme_bw()

# produce a boxplot of the data
ggplot(scores, aes(x = Sex, y = Violence, fill = Conds)) + 
  geom_boxplot(position = position_dodge(1), 
               outlier.colour = "blue",
               outlier.size = 3) +
  coord_flip()

# going to summarise the data but group it by the different conditions
scores_sub <- group_by(scores, Sex, Conds)

# calculate mean, median, std and ci of data
scores_sum <- summarise(scores_sub, 
                        mscore = mean(Violence), 
                        mdscore = median(Violence), 
                        stdscore = sd(Violence), 
                        ci = 1.96 * stdscore / sqrt(n()))
       
# produce a bargraph of the data
ggplot(scores_sum, aes(x = Sex, y = mscore, fill = Conds)) + 
  geom_bar(stat = "identity", 
           position = position_dodge(width = .9), 
           colour = "black") +
  scale_fill_manual(values=c("#FFFFFF", "#999999")) +
  labs(title = "BarGraph of Something") +
  labs(y = "Counts of Violent Acts") +
  geom_errorbar(aes(ymin = mscore - ci, ymax = mscore + ci), 
                position = position_dodge(width = .9), width = .25)


