### Part 1: Recapping correlations - 10-15 minutes

# Going to start off with some basics about correlations to get everyone up to speed.
# Usual stuff about strength and direction but in an interactive way using:
# http://guessthecorrelation.com/ and going round members of group to test visual literacy.
# The rules:
# guess within 0.05 of the true correlation: +1 life and +5 coins
# guess within 0.10 of the true correlation: +1 coin
# guess within >0.10 of the true correlation: -1 life




### Part 2: How to test if a correlation is significant - 10-15 minutes

# Will show basic formula on screen for the one-sample t-test
r <- .38   #where r is the correlation co-efficient
N <- 30    #where N is the number of pairings.
# using formula t(N-2) = (r * sqrt(N-2)) / sqrt(1-r^2)

# my_t <- (.38 * sqrt(30 - 2)) / sqrt(1 - .38^2)      # will show this way first
my_t <- (r * sqrt(N - 2)) / sqrt(1 - r^2)             # will show this way second
p_value <- 2 * pt(my_t, N - 2, lower.tail = FALSE)    # will remind people of pt, lower.tail, and two-tail.
cat("The t-value is: ", round(my_t,3), "\n")
cat("with a p-value of: ", round(p_value,3), "\n")



### Part 3: Using the iris data to look at cor vs rcorr - 10-15 minutes

head(iris) # Fsher dataset giving 4 measurements regarding 50 examples of 3 types of Iris flowers

# create scatter plot of Sepal.Length by Sepal.Width
plot(iris$Sepal.Width,iris$Sepal.Length) # base R
# or
install.packages("ggplot2")
library(ggplot2)
ggplot(iris, aes(Sepal.Width, Sepal.Length)) + geom_point(colour = "red", size = 3)

# correlate Sepal.Length with Sepal.Width and check p-value
Sep_rLBW <- cor(iris[1],iris[2])
Sep_t <- (Sep_rLBW * sqrt(length(iris[, 1]) - 2)) / sqrt(1 - Sep_rLBW^2)
Sep_p <- 2 * pt(Sep_t, (length(iris[, 1]) - 2), lower.tail = FALSE)   # but hang-on, it is a negative t, so we need to use TRUE

# Surely there is a quicker way of doing a correlation and getting a p-value
install.packages("Hmisc")
library(Hmisc)
rcorr(iris[, 1],iris[, 2])  # gives r values and p-values

# of course maybe you want to look at all correlations in the 4 measures - it being much quicker.
iris_mx <- as.matrix(iris[, -5])
rcorr(iris_mx)
# you may even want to plot all the correlations in a scatterplot matrix
pairs(iris_mx)


### Part 4  - Level 1 LAB 4: The Stroop effect and BDI - 30 minutes

# In this lab students take part in a short stroop experiment where 20 negative and 20 neutral words
# are put into a 4 color stroop test.  Participants respond to the color of the word as per normal
# and the reaction times for correct responses are measured, and averaged for each participant to give
# an average RT for Neutral words and Negative Words for each participant. This data is stored in my_data.csv

# Previously, Mitterschiffthaler et al., (2008) compared the reaction times of depressed 
# and nondepressed people, on both neutral and negative words in an emotional Stroop task.
# In comparison to the non-depressed participants, depressed participants took longer
# to respond to negative words than neutral words. Similarly, in a study of the elderly,
# Broomfield et al., (2007) compared depressed people with non-depressed people
# and found that response times to negative words in comparison to other word types
# were slower in the depressed population than in the healthy population.

# Based on literature, students test:
# H1 - that there is a positive correlation between BDI and RT for Negative words
# &
# H0 - that there is no relationship between BDI and RT for Neutral words

# Task:
# Produce a code that will:
# 1) Calculate means and standard error of RT for Negative and Neutral words
# 2) Check normality of BDI, RT Negative and RT Neutral via histograms
# 3) Plot relationship of the three variables
# 4) Test the two hypotheses





### Part 5 - Going over results, or we can release a code after class for them to check.

