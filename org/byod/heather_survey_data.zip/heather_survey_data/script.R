library("readxl")
library("dplyr")
library("tidyr")

to_read <- list.files()

dat1 <- read_excel(to_read[1], sheet = 2L) %>%
  mutate(new_id = toupper(gsub("[\\., ]", "", ID))) %>%
  filter(!is.na(new_id)) %>%
  select(new_id, 1:10) %>%
  gather(Question, Response, -new_id) %>%
  arrange(new_id) %>%
  mutate(Wave = 1L)

dat2 <- read_excel(to_read[2], sheet = 2L) %>%
  mutate(new_id = toupper(gsub("[\\., ]", "", ID))) %>%
  filter(!is.na(new_id)) %>%
  select(new_id, 1:10) %>%
  gather(Question, Response, -new_id) %>%
  arrange(new_id) %>%
  mutate(Wave = 2L)

## how many students in table 2 are also in table 1
semi_join(dat1, dat2, "new_id") %>%
  select(new_id)

## which students did not complete 2nd wave
no_2nd <- anti_join(dat1, dat2, "new_id") %>%
  select(new_id)



## which students completed 2 but not 1
no_1st <- anti_join(dat2, dat1, "new_id") %>%
  select(new_id)
